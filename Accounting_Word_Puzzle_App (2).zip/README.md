# Accounting Word Puzzle Application

This app is based on the supplied Accounting Word Puzzle Application assignment.

## Features
- 15 accounting questions from the assignment
- Fill-in-the-blank clue format
- Easy/Medium question labels
- Answer checking
- 10 points per correct answer
- Hint feature
- Next-question flow
- Final score and percentage
- Streamlit interface

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Publish
Deploy `app.py` and `requirements.txt` to Streamlit Community Cloud.

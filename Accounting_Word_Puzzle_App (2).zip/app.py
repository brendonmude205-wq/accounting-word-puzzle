import streamlit as st
import random

st.set_page_config(page_title="Accounting Word Puzzle", page_icon="📚", layout="centered")

QUESTIONS = [
    {"clue":"Money invested by the owner in a business.", "answer":"capital", "level":"Easy"},
    {"clue":"Resources owned by a business.", "answer":"assets", "level":"Easy"},
    {"clue":"Amount owed by a business to outsiders.", "answer":"liabilities", "level":"Easy"},
    {"clue":"Income earned from selling goods or services.", "answer":"revenue", "level":"Easy"},
    {"clue":"Cost incurred to earn revenue.", "answer":"expense", "level":"Easy"},
    {"clue":"The book in which business transactions are first recorded.", "answer":"journal", "level":"Easy"},
    {"clue":"Book containing separate accounts for transactions.", "answer":"ledger", "level":"Easy"},
    {"clue":"Statement prepared to check the arithmetical accuracy of ledger balances.", "answer":"trial balance", "level":"Medium"},
    {"clue":"Financial statement showing financial position.", "answer":"balance sheet", "level":"Medium"},
    {"clue":"Excess of revenue over expenses.", "answer":"profit", "level":"Easy"},
    {"clue":"Excess of expenses over revenue.", "answer":"loss", "level":"Easy"},
    {"clue":"Reduction in the value of a fixed asset over time.", "answer":"depreciation", "level":"Medium"},
    {"clue":"Amount withdrawn by the owner for personal use.", "answer":"drawings", "level":"Medium"},
    {"clue":"Amount received from customers against credit sales.", "answer":"debtor", "level":"Medium"},
    {"clue":"Person or business to whom money is owed.", "answer":"creditor", "level":"Medium"},
]

if "questions" not in st.session_state:
    st.session_state.questions = QUESTIONS.copy()
    random.shuffle(st.session_state.questions)
    st.session_state.index = 0
    st.session_state.score = 0
    st.session_state.answered = False
    st.session_state.hint_used = False
    st.session_state.message = ""

def reset_game():
    st.session_state.questions = QUESTIONS.copy()
    random.shuffle(st.session_state.questions)
    st.session_state.index = 0
    st.session_state.score = 0
    st.session_state.answered = False
    st.session_state.hint_used = False
    st.session_state.message = ""

st.title("📚 Accounting Word Puzzle")
st.caption("Interactive learning application • Accounting terminology practice")

with st.sidebar:
    st.header("Game Controls")
    if st.button("🔄 New Game", use_container_width=True):
        reset_game()
        st.rerun()
    st.info("10 points for every correct answer. One hint is available per question.")

idx = st.session_state.index

if idx >= len(st.session_state.questions):
    total = len(st.session_state.questions) * 10
    pct = (st.session_state.score / total) * 100 if total else 0
    st.success("🎉 All puzzles completed!")
    st.metric("Final Score", f"{st.session_state.score}/{total}")
    st.metric("Percentage", f"{pct:.0f}%")
    if pct >= 80:
        st.balloons()
        st.write("🌟 Excellent performance!")
    elif pct >= 50:
        st.write("👍 Good work! Keep revising accounting terms.")
    else:
        st.write("📖 Keep practising and try again.")
    st.stop()

q = st.session_state.questions[idx]

st.progress(idx / len(st.session_state.questions))
st.write(f"**Question {idx+1} of {len(st.session_state.questions)}**  |  Level: **{q['level']}**")
st.subheader("Clue")
st.write(q["clue"])

answer = st.text_input("Your answer", key=f"answer_{idx}",
                       disabled=st.session_state.answered,
                       placeholder="Type the accounting term")

c1, c2 = st.columns(2)
with c1:
    if st.button("✅ Check Answer", use_container_width=True, disabled=st.session_state.answered):
        if answer.strip().lower() == q["answer"]:
            st.session_state.score += 10
            st.session_state.message = "correct"
        else:
            st.session_state.message = "incorrect"
        st.session_state.answered = True
        st.rerun()

with c2:
    if st.button("💡 Hint", use_container_width=True, disabled=st.session_state.answered):
        st.session_state.hint_used = True
        st.rerun()

if st.session_state.hint_used and not st.session_state.answered:
    a = q["answer"]
    st.info(f"Hint: The answer starts with **{a[0].upper()}** and has **{len(a.replace(' ', ''))} letters**.")

if st.session_state.message == "correct":
    st.success("🎯 Correct! +10 points")
elif st.session_state.message == "incorrect":
    st.error(f"❌ Incorrect. Correct answer: **{q['answer'].upper()}**")

if st.session_state.answered:
    st.write(f"**Current Score:** {st.session_state.score}")
    if st.button("➡️ Next Question", use_container_width=True):
        st.session_state.index += 1
        st.session_state.answered = False
        st.session_state.hint_used = False
        st.session_state.message = ""
        st.rerun()
else:
    st.write(f"**Current Score:** {st.session_state.score}")

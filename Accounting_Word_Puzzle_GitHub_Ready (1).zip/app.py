import streamlit as st
import random
import time
from pathlib import Path

st.set_page_config(
    page_title="Accounting Word Puzzle",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# -------------------- DATA --------------------
QUESTIONS = [
    ("Money invested by the owner in a business.", "CAPITAL", "Easy"),
    ("Resources owned by a business.", "ASSETS", "Easy"),
    ("Amount owed by a business to outsiders.", "LIABILITIES", "Easy"),
    ("Income earned from selling goods or services.", "REVENUE", "Easy"),
    ("Cost incurred to earn revenue.", "EXPENSE", "Easy"),
    ("The book in which business transactions are first recorded.", "JOURNAL", "Easy"),
    ("Book containing separate accounts for transactions.", "LEDGER", "Easy"),
    ("Statement prepared to check the arithmetical accuracy of ledger balances.", "TRIAL BALANCE", "Medium"),
    ("Financial statement showing financial position.", "BALANCE SHEET", "Medium"),
    ("Excess of revenue over expenses.", "PROFIT", "Easy"),
    ("Excess of expenses over revenue.", "LOSS", "Easy"),
    ("Reduction in the value of a fixed asset over time.", "DEPRECIATION", "Medium"),
    ("Amount withdrawn by the owner for personal use.", "DRAWINGS", "Medium"),
    ("Amount received from customers against credit sales.", "DEBTOR", "Medium"),
    ("Person or business to whom money is owed.", "CREDITOR", "Medium"),
]

MCQ_EXTRA = [
    ("Which accounting equation is correct?", ["Assets = Liabilities + Capital", "Assets = Revenue + Expense", "Capital = Assets + Liabilities", "Revenue = Assets + Drawings"], "Assets = Liabilities + Capital"),
    ("Which book records transactions first?", ["Ledger", "Journal", "Trial Balance", "Balance Sheet"], "Journal"),
    ("Which item is an expense?", ["Capital", "Rent", "Debtor", "Creditor"], "Rent"),
    ("Which statement shows financial position?", ["Trading Account", "Cash Book", "Balance Sheet", "Journal"], "Balance Sheet"),
    ("Profit occurs when:", ["Expenses exceed revenue", "Revenue exceeds expenses", "Assets equal zero", "Liabilities exceed capital"], "Revenue exceeds expenses"),
]

def normalize(s):
    return " ".join(s.strip().upper().split())

def reset():
    st.session_state.mode = "Home"
    st.session_state.q_index = 0
    st.session_state.score = 0
    st.session_state.correct = 0
    st.session_state.answered = False
    st.session_state.feedback = ""
    st.session_state.start_time = time.time()
    st.session_state.player = ""
    st.session_state.mode_questions = []
    st.session_state.scramble = None
    st.session_state.search_grid = None
    st.session_state.found = False

if "mode" not in st.session_state:
    reset()

# -------------------- CSS --------------------
st.markdown("""
<style>
.block-container {max-width: 1180px; padding-top: 1.2rem;}
.hero {
    padding: 2rem; border-radius: 22px; text-align:center;
    background: linear-gradient(135deg,#0f172a,#1d4ed8);
    color:white; margin-bottom:1.2rem;
}
.hero h1 {font-size:2.8rem; margin:0;}
.hero p {font-size:1.1rem; opacity:.9;}
.card {
    padding:1.2rem; border-radius:18px; border:1px solid #dbe3ef;
    background:#ffffff; box-shadow:0 6px 18px rgba(15,23,42,.06);
}
.stat {
    padding:1rem; border-radius:16px; background:#f1f5f9;
    text-align:center;
}
.small {color:#64748b;}
@media (max-width: 700px) {
  .hero h1 {font-size:2rem;}
  .block-container {padding-left:.7rem; padding-right:.7rem;}
}
</style>
""", unsafe_allow_html=True)

# -------------------- HEADER --------------------
st.markdown("""
<div class="hero">
  <div style="font-size:3rem">📊</div>
  <h1>ACCOUNTING WORD PUZZLE</h1>
  <p>Learn accounting. Solve puzzles. Build your score.</p>
</div>
""", unsafe_allow_html=True)

# -------------------- SIDEBAR --------------------
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/accounting.png", width=72)
    st.title("Game Menu")
    if st.button("🏠 Home", use_container_width=True):
        st.session_state.mode = "Home"
        st.rerun()
    if st.button("🧩 Fill in the Blank", use_container_width=True):
        st.session_state.mode = "Fill"
        st.session_state.mode_questions = QUESTIONS.copy()
        random.shuffle(st.session_state.mode_questions)
        st.session_state.q_index = 0
        st.session_state.answered = False
        st.session_state.feedback = ""
        st.session_state.start_time = time.time()
        st.rerun()
    if st.button("🎯 Multiple Choice", use_container_width=True):
        st.session_state.mode = "MCQ"
        st.session_state.mode_questions = MCQ_EXTRA.copy()
        random.shuffle(st.session_state.mode_questions)
        st.session_state.q_index = 0
        st.session_state.answered = False
        st.session_state.feedback = ""
        st.session_state.start_time = time.time()
        st.rerun()
    if st.button("🔤 Word Scramble", use_container_width=True):
        st.session_state.mode = "Scramble"
        st.session_state.q_index = 0
        st.session_state.mode_questions = QUESTIONS.copy()
        random.shuffle(st.session_state.mode_questions)
        st.session_state.answered = False
        st.session_state.feedback = ""
        st.session_state.start_time = time.time()
        st.rerun()
    if st.button("🔎 Word Search", use_container_width=True):
        st.session_state.mode = "Search"
        st.session_state.search_grid = None
        st.session_state.found = False
        st.rerun()
    if st.button("🏆 Leaderboard", use_container_width=True):
        st.session_state.mode = "Leaderboard"
        st.rerun()
    st.divider()
    st.caption("Based on the supplied Accounting Word Puzzle assignment.")

# -------------------- HOME --------------------
if st.session_state.mode == "Home":
    st.subheader("Welcome 👋")
    st.write("Choose a game mode from the menu and test your accounting knowledge.")
    c1,c2,c3,c4 = st.columns(4)
    for col, title, value in zip(
        [c1,c2,c3,c4],
        ["Questions","Modes","Points","Hint"],
        ["15+","5","10","1/question"]
    ):
        with col:
            st.markdown(f'<div class="stat"><b>{title}</b><br><span style="font-size:1.5rem">{value}</span></div>', unsafe_allow_html=True)
    st.divider()
    st.info("Tip: Start with Fill in the Blank, then try Multiple Choice and Word Scramble.")

# -------------------- FILL / SCRAMBLE --------------------
elif st.session_state.mode in ("Fill", "Scramble"):
    qs = st.session_state.mode_questions
    i = st.session_state.q_index
    if i >= len(qs):
        st.success(f"🎉 Finished! Score: {st.session_state.score}")
        if st.button("Play Again"):
            st.session_state.mode = "Home"
            st.rerun()
        st.stop()

    clue, answer, level = qs[i]
    st.progress((i+1)/len(qs))
    st.write(f"### Question {i+1} / {len(qs)}  •  {level}")

    if st.session_state.mode == "Fill":
        st.markdown(f'<div class="card"><h3>Clue</h3><p>{clue}</p></div>', unsafe_allow_html=True)
        user = st.text_input("Your answer", disabled=st.session_state.answered, key=f"fill_{i}")
    else:
        letters = st.session_state.get("scramble")
        if letters is None or st.session_state.get("scramble_index") != i:
            letters = list(answer.replace(" ",""))
            random.shuffle(letters)
            st.session_state.scramble = "".join(letters)
            st.session_state.scramble_index = i
        st.markdown(f'<div class="card"><h3>Unscramble</h3><p style="font-size:2rem;letter-spacing:.35rem"><b>{st.session_state.scramble}</b></p><p>{clue}</p></div>', unsafe_allow_html=True)
        user = st.text_input("Unscrambled answer", disabled=st.session_state.answered, key=f"scr_{i}")

    if not st.session_state.answered:
        a,b = st.columns(2)
        with a:
            if st.button("✅ Check Answer", use_container_width=True):
                if normalize(user) == normalize(answer):
                    st.session_state.score += 10
                    st.session_state.correct += 1
                    st.session_state.feedback = "correct"
                else:
                    st.session_state.feedback = "incorrect"
                st.session_state.answered = True
                st.rerun()
        with b:
            if st.button("💡 Hint", use_container_width=True):
                clean = answer.replace(" ","")
                st.info(f"Starts with **{clean[0]}** • {len(clean)} letters")
    else:
        if st.session_state.feedback == "correct":
            st.success("🎯 Correct! +10 points")
        else:
            st.error(f"❌ Correct answer: **{answer}**")
        if st.button("➡️ Next Question", use_container_width=True):
            st.session_state.q_index += 1
            st.session_state.answered = False
            st.session_state.feedback = ""
            st.session_state.scramble = None
            st.rerun()
    st.metric("Score", st.session_state.score)

# -------------------- MCQ --------------------
elif st.session_state.mode == "MCQ":
    qs = st.session_state.mode_questions
    i = st.session_state.q_index
    if i >= len(qs):
        st.success(f"🎉 Finished! Score: {st.session_state.score}")
        st.stop()
    clue, options, correct = qs[i]
    st.progress((i+1)/len(qs))
    st.write(f"### Question {i+1} / {len(qs)}")
    st.markdown(f'<div class="card"><h3>{clue}</h3></div>', unsafe_allow_html=True)
    choice = st.radio("Choose one:", options, disabled=st.session_state.answered, key=f"mcq_{i}")
    if not st.session_state.answered and st.button("✅ Submit Answer", use_container_width=True):
        if choice == correct:
            st.session_state.score += 10
            st.session_state.correct += 1
            st.session_state.feedback = "correct"
        else:
            st.session_state.feedback = "incorrect"
        st.session_state.answered = True
        st.rerun()
    if st.session_state.answered:
        if st.session_state.feedback == "correct":
            st.success("🎯 Correct! +10 points")
        else:
            st.error(f"❌ Correct answer: **{correct}**")
        if st.button("➡️ Next Question", use_container_width=True):
            st.session_state.q_index += 1
            st.session_state.answered = False
            st.session_state.feedback = ""
            st.rerun()
    st.metric("Score", st.session_state.score)

# -------------------- WORD SEARCH --------------------
elif st.session_state.mode == "Search":
    st.subheader("🔎 Accounting Word Search")
    words = ["ASSETS","CAPITAL","REVENUE","PROFIT","LOSS","LEDGER","JOURNAL","DEBTOR","CREDITOR","DRAWINGS"]
    st.write("Find these words in the grid: " + ", ".join(words))
    size = 12
    if st.session_state.search_grid is None:
        grid = [[random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ") for _ in range(size)] for _ in range(size)]
        for word in words[:5]:
            r = random.randrange(size)
            c = random.randrange(size-len(word)+1)
            for j,ch in enumerate(word):
                grid[r][c+j] = ch
        st.session_state.search_grid = grid
    grid = st.session_state.search_grid
    st.code("\n".join(" ".join(row) for row in grid), language=None)
    found = st.multiselect("Which words did you find?", words)
    if st.button("Check Found Words"):
        if len(found) >= 5:
            st.success("🎉 Great! You found enough accounting terms.")
            st.session_state.score += 20
        else:
            st.warning("Keep looking. Try to find at least 5 words.")
    if st.button("New Grid"):
        st.session_state.search_grid = None
        st.rerun()

# -------------------- LEADERBOARD --------------------
elif st.session_state.mode == "Leaderboard":
    st.subheader("🏆 Leaderboard")
    st.write("Demo leaderboard for the GitHub-ready version.")
    board = [
        ("Accounting Master", 140),
        ("Ledger Pro", 120),
        ("Balance Champion", 100),
        ("Future Auditor", st.session_state.score),
    ]
    board.sort(key=lambda x:x[1], reverse=True)
    for rank,(name,score) in enumerate(board,1):
        st.markdown(f"**#{rank} — {name}**  |  {score} points")
    st.info("For permanent multi-user scores, connect this page to SQLite, Supabase, Firebase, or another hosted database.")

st.divider()
st.caption("Accounting Word Puzzle • Educational Mini Project • Python + Streamlit")

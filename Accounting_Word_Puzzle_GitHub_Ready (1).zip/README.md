# 📊 Accounting Word Puzzle

A professional, mobile-friendly Streamlit educational game based on the supplied Accounting Word Puzzle Application assignment.

## Features
- Professional title/hero screen
- Accounting-themed logo/icon
- Fill-in-the-Blank
- Multiple Choice
- Word Scramble
- Word Search
- 10-point scoring
- Hints
- Progress indicators
- Leaderboard demo
- Responsive/mobile-friendly CSS
- GitHub-ready project structure

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Publish on Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt`.
3. Open Streamlit Community Cloud.
4. Select the GitHub repository and `app.py`.
5. Deploy.

The app will receive a public URL after deployment.

## Academic basis

The supplied assignment specifies an Accounting Word Puzzle application using Python, Streamlit/Gradio, at least 15 accounting questions, answer validation, 10 points per correct answer, hints, final score/percentage, testing, and future enhancements such as leaderboards and mobile-friendly versions.
